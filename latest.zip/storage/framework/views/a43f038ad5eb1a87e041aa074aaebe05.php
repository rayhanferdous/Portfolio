<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 grid-margin stretch-card">

        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Testimonial Records</h4>
                <p class="card-description"> Website Testimonial Section Information </p>
                <a href="<?php echo e(route('admin.testimonial.create')); ?>">
                    <button type="button" class="btn btn-primary btn-fw ">Add New</button>
                </a>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th> # </th>
                            <th> Name </th>
                            <th> Content </th>
                            <th> Date </th>
                            <th> Manage </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($item->id); ?> </td>
                                <td><?php echo e($item->name); ?> </td>
                                <td style="white-space: initial;">
                                    <?php echo e($item->content); ?>

                                </td>
                                <td><?php echo e($item->date); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('admin.testimonial.edit', $item->id)); ?>">
                                        <button type="button" class="btn btn-success btn-sm">Edit</button>
                                    </a>
                                    <form type="submit" method="POST"
                                        action="<?php echo e(route('admin.testimonial.destroy', $item->id)); ?>"
                                        onsubmit="return confirm('Are you sure?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rayhan-ferdous/Documents/WorkSpace/Portfolio/resources/views/admin/testimonial/index.blade.php ENDPATH**/ ?>