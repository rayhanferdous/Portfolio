<?php $__env->startSection('content'); ?>
    
    <section style="margin-top: 100px;">
        <div class="container">
            <?php if(isset($heroSection)): ?>

                <div class="banner rounded-4 p-5"
                    style="background-image: url(<?php echo e(asset($heroSection->hero_image)); ?>); background-size: cover ; background-repeat: no-repeat; background-position: center;">
                    <div class="text-content text-white py-5 my-5">
                        <?php if($heroSection->hero_small_title): ?>
                            <p class="fs-4">
                                <?php echo e($heroSection->hero_small_title); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($heroSection->hero_title): ?>
                            <h1 class="display-1">
                                <?php echo implode('<br>', explode(' ', $heroSection->hero_title)); ?>

                            </h1>
                        <?php endif; ?>
                    </div>
                    <div class="row text-uppercase bg-black rounded-4 p-3 mt-5">
                        <?php if($heroSection->years_of_experience): ?>
                            <div class="col-md-3">
                                <div class="d-flex align-items-center gap-4">
                                    <h2 class="display-2 text-light">
                                        <?php echo e($heroSection->years_of_experience); ?>

                                    </h2>
                                    <p class="text-light-emphasis justify-content-center m-0 ls-4">
                                        Years of <br> experience
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($heroSection->number_of_awards): ?>
                            <div class="col-md-3">
                                <div class="d-flex align-items-center gap-4">
                                    <h2 class="display-2 text-light">
                                        <?php echo e($heroSection->number_of_awards); ?>

                                    </h2>
                                    <p class="text-light-emphasis justify-content-center m-0 ls-4">
                                        Number of <br> awards
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($heroSection->number_of_pubs): ?>
                            <div class="col-md-3">
                                <div class="d-flex align-items-center gap-4">
                                    <h2 class="display-2 text-light">
                                        <?php echo e($heroSection->number_of_pubs); ?>

                                    </h2>
                                    <p class="text-light-emphasis justify-content-center m-0 ls-4">
                                        Number of <br> publications
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($heroSection->number_of_published_news): ?>
                            <div class="col-md-3">
                                <div class="d-flex align-items-center gap-4">
                                    <h2 class="display-2 text-light">
                                        <?php echo e($heroSection->number_of_published_news); ?>

                                    </h2>
                                    <p class="text-light-emphasis justify-content-center m-0 ls-4">
                                        Number of <br> published news
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>
    
    
    
    
    <section>
        <div class="container">
            <div class="row">
                
                <div class="col-lg-4">
                    <div class="h-100 bg-yellow p-4 rounded-4">
                        <h3>
                            Education
                        </h3>
                        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="py-4">
                                <p class="text-dark-emphasis">
                                    <?php echo e($education->to); ?> - <?php echo e($education->from); ?>

                                </p>
                                <h5>
                                    <?php echo e($education->title); ?>

                                </h5>
                                <p class="text-dark-emphasis">
                                    <?php echo e($education->association); ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="h-100 bg-green p-4 rounded-4">
                        <h3>
                            Experiences
                        </h3>
                        <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="py-4">
                                <p class="text-dark-emphasis">
                                    <?php echo e($experience->to); ?> - <?php echo e($experience->from); ?>

                                </p>
                                <h5>
                                    <?php echo e($experience->association); ?> .: <?php echo e($experience->title); ?>

                                </h5>
                                <p class="text-dark-emphasis">
                                    <?php echo e($experience->description); ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="h-100 bg-teal p-4 rounded-4">
                        <h3>
                            Publications
                        </h3>
                        <div class="py-4">
                            <p class="text-dark-emphasis">
                                1998 - 2004
                            </p>
                            <h5>
                                Bachelors in Engineering in Information Technology
                            </h5>
                            <p class="text-dark-emphasis">
                                Bachelors in Engineering in Information Technology
                            </p>
                        </div>
                        <p class="text-dark-emphasis">
                            2004 - 2006
                        </p>
                        <h5>
                            Masters in Data Analysis
                        </h5>
                        <p class="text-dark-emphasis">
                            Harvard School of Science and management
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    
    
    
    <section class="portfolio py-5">
        <div class="container">
            <div class="justify-content-center">

                <div class="row justify-content-center">

                    <div class="col-lg-6" data-aos="fade-up">
                        <div class="section-header text-center">
                            <h4 class="fw-bold fs-2 txt-fx slide-up">
                                Awards Video/Image
                            </h4>
                        </div><!--section-header-->
                    </div>

                    <div id="filters" class="button-group d-flex flex-wrap gap-3 justify-content-center py-5"
                        data-aos="fade-up">
                        <a href="#" class="btn btn-primary text-decoration-none text-uppercase is-checked"
                            data-filter=".photography">Images</a>
                        
                    </div>
                </div>

                <div class="grid p-0 clearfix row row-cols-2 row-cols-lg-3 row-cols-xl-4" data-aos="fade-up">
                    <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col mb-4 portfolio-item photography <?php echo e($award->category); ?>">
                            <a href="<?php echo e(asset($award->image)); ?>" data-lightbox="portfolio" data-title="<?php echo e($award->title); ?>"
                                title="<?php echo e($award->title); ?>"><img src="<?php echo e(asset($award->image)); ?>" class="img-fluid rounded-4"
                                    alt="portfolio"></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </div>

                <div class="text-center p-3">
                    <a href="index.html" class="btn btn-outline-dark btn-lg mt-3 text-uppercase text-decoration-none">
                        View All Works
                    </a>
                </div>

            </div>
    </section>
    
    <section class="py-5">
        <div class="container">
            <div class="text-center">
                <h2 class="display-3">
                    Latest News
                </h2>
                <p>
                    Accusan maiores alias conseaut equatur aut perferendi.
                </p>
            </div>
            <div class="row py-4">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($newsItem->published_link); ?>" target="_blank" class="col-lg-6 p-3">
                        <div class="post-item p-3 border rounded-5">
                            <div class="row g-md-5">
                                <div class="col-lg-5">
                                    <img src="<?php echo e(asset($newsItem->thumbnail)); ?>" class="img-fluid rounded-4">
                                </div>
                                <div class="col-lg-7">
                                    <p class="text-uppercase text-muted mt-3">
                                        <?php echo e($newsItem->type); ?> / <?php echo e(date('M d, Y', strtotime($newsItem->published_at))); ?>

                                    </p>
                                    <h3>
                                        <?php echo e($newsItem->title); ?>

                                    </h3>
                                </div>

                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="text-center">
                <button type="button" class="btn btn-outline-dark btn-lg mt-3 btn-color text-uppercase">
                    View All Blogs
                </button>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="text-center">
                <h2 class="display-3 mb-5">
                    Testimonials
                </h2>
            </div>

            <div class="swiper testimonial-swiper">
                <div class="swiper-wrapper ">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="testimonial-card rounded-3 py-4 px-4 swiper-slide">
                            <div class="text-start ">
                                <p>
                                    <?php echo e($testimonial->content); ?>

                                </p>
                                <h5>
                                    <?php echo e($testimonial->name); ?>

                                </h5>
                                <p class="postd">
                                    <?php echo e(date('M d, Y', strtotime($testimonial->date))); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="testimonial-swiper-pagination position-relative mt-5 text-center"></div>
            </div>

        </div>
    </section>

    <section>
        <div class="container">
            <div class="text-center pt-5">
                <h2 class="display-3">
                    FAQs
                </h2>
            </div>
            <div class="row mt-5">
                <div class="col-lg-6">
                    <img src="<?php echo e(asset('import/assets/images/illustration-6.png')); ?>" class="img-fluid">
                </div>
                <div class="col-lg-6">
                    <div class="accordion accordion-flush" id="accordion-flush">
                        <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item border mb-3 rounded-3">
                                <h5 class="accordion-header">
                                    <button class="accordion-button collapsed" style="font-weight:bold;" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($item->id); ?>" aria-expanded="true"
                                        aria-controls="collapse<?php echo e($item->id); ?>">
                                        <?php echo e($item->question); ?>

                                    </button>
                                </h5>
                                <div id="collapse<?php echo e($item->id); ?>"
                                    class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                                    data-bs-parent="#accordion-flush">
                                    <div class=" accordion-body">
                                        <p><?php echo e($item->answer); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="p-5 bg-yellow py-5">
        <div class="container">
            <div class="row justify-content-center my-5">
                <div class="col-md-5">
                    <h6>
                        Quick Contact
                    </h6>
                    <h2 class="display-3">
                        Leave a Message
                    </h2>
                    <p>
                        Labore accusam in modo compungi, iacentem substantiales um se sed esse haec.
                    </p>
                </div>
                <div class="col-md-5">
                    <div class="mb-3">
                        <input type="name" class="form-control p-3 rounded-4" name="name" id="name"
                            aria-describedby="nameHelpId" placeholder="your name" />
                    </div>
                    <div class="mb-3">
                        <input type="email" class="form-control p-3 rounded-4" name="email" id="email"
                            aria-describedby="emailHelpId" placeholder="your email" />
                    </div>
                    <div class="mb-3">
                        <textarea class="form-control p-3 rounded-4" name="your message" placeholder="your message"
                            id="message" rows="3"></textarea>
                    </div>
                    <div class="d-grid">
                        <button type="button" class="btn btn-dark btn-lg text-uppercase rounded-4">
                            Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rayhan-ferdous/Documents/WorkSpace/Portfolio/resources/views/home.blade.php ENDPATH**/ ?>