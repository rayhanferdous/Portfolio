<?php $__env->startSection('content'); ?>
<div class="main-panel">
  <div class="content-wrapper">
    <div class="page-header">
      <h3 class="page-title">
        <span class="page-title-icon bg-gradient-primary text-white me-2">
          <i class="mdi mdi-home"></i>
        </span> Welcome to Admin Page Dear/ <b><?php echo e($auth_user); ?></b>
      </h3>

      

    </div> 
  </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rayhan-ferdous/Documents/WorkSpace/Portfolio/resources/views/admin/index.blade.php ENDPATH**/ ?>